from django.contrib import admin
from .models import Config


# Register your models here.
admin.site.register(Config)