from django.db import models

# Create your models here.
class Config(models.Model):
    direct = models.BooleanField(default=True)
    create_at = models.DateTimeField(auto_now=True)
