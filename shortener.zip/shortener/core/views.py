import base64
from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.contrib.auth import login as auth_login, logout as auth_logout,authenticate
from .models import Config 

# Create your views here.
def home(request):
    config = Config.objects.last()
    context = {
        'direct':False,
    }
    if config.direct == True:
        context['direct'] = True
    return render(request,'home.html',context)


def login(request):
    if request.user.is_authenticated:
        return redirect('/')
    
    context = {}

    if request.method == 'POST':
        data = request.POST
        user = authenticate(username=data['login'], password=data['password'])
        if user is not None:
            auth_login(request,user)
            return redirect('/')
        else:
            request.session['log_err'] = 'Ha ocurrido un problema.'
            return redirect('/login')
    else:
        if 'log_err' in request.session:
            if request.session['log_err'] is not None:
                context['error'] = request.session['log_err']
                request.session['log_err'] = None

    return render(request,'login.html',context)


def logout(request):
    if request.user.is_authenticated:
        auth_logout(request)
    return redirect('/')


def go(request):
    config = Config.objects.last()
    if config.direct == True:
        dir = ''
        if 'dir' in request.GET:
            dir = request.GET['dir']
        return redirect(str(base64.b64decode(dir).decode()))    
    return render(request,'go.html',{})